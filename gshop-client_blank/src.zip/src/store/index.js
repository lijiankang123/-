//src/store/index.js
//src/store.js 保存vuex中所有数据
//实现对象count数据存储与操作
//1:引入vuex模块
import Vue from "vue"
import Vuex from "vuex"

//1.1:引入ajax函数
import {reqUserInfo,reqLogout, reqShopInfo,reqShopGoods} from "../api"
//2:将vuex注册vue对象
Vue.use(Vuex)
//3:创建对象state对象[菜品]
const state = {
    userInfo:{},   //用户信息对象
    info:{},       //商家信息
    goods:[],      //商家商品列表
}
//4:创建对象mutations对象[厨师]
const mutations = {
    //接收用户信息，保存至state
    RECEIVE_USER_INFO(state,{userInfo}){
       state.userInfo = userInfo
    },
    //重置用户信息
    RESET_USER_INFO(state){
      state.userInfo = {}
    },
    //接收商家信息
    RECEIVE_INFO(state,{info}){
      state.info = info
    },
    //接收商家商品列表
    RECEIVE_GOODS(state,{goods}){
      state.goods = goods
    }
}
//5:创建对象actions对象[服务员]
const actions = {
    //5.1:获取服务器中用户信息并且保存  14:15 完成此任务
    async getUserInfo({commit}){
      //5.1.1 发送请求
      //result {code:1,data:{id:...}}
      const result = await reqUserInfo();
      //5.1.2 将用户信息保存vuex code 大于零正确
      if(result.code>0){
        const userInfo = result.data;//用户信息
        commit("RECEIVE_USER_INFO",{userInfo})//提交
      }
    },
    //5.2:完成用户退出功能
    async logout({commit}){
       //5.2.1 发送请求完成服务器退出任务
       const  result = await reqLogout();
       //5.2.2 如果服务器返回正确信息,清除vuex中用户状态数据
       if(result.code === 0 ){
          commit("RESET_USER_INFO");
       }
    },
    //5.3:获取商家信息
    async getShopInfo({commit}){
         //5.3.1 获取商家信息?? 上面引入
         const result = await reqShopInfo();
         //5.3.2 如果信息正确
         if(result.code == 0 ){
           const info = result.data;
           commit("RECEIVE_INFO",{info})
         }
         //5.3.3 将商家信息保存vuex
    },
    //5.4:获取商家商品列表信息
    async getShopGoods({commit}){
      //5.4.1 获取商家信息?? 上面引入
      const result = await reqShopGoods();
      //5.4.2 如果信息正确
      if(result.code == 0 ){
        const goods = result.data;
        commit("RECEIVE_GOODS",{goods})
      }
      //5.4.3 将商家信息保存vuex       
    }
}
//6:创建vuex配置并导出
export default new Vuex.Store({
  state,
  mutations,
  actions  
})