<!--  -->
<template>
  <div>
    <div class="goods">
      <!--左侧商品类别列表--菜单-->
      <div class="menu-wrapper" ref="menuWrapper">
        <ul>
          <li class="menu-item" v-for="(good,index) in goods" :key="index">
            <span class="text bottom-border-1px">
              <img
                class="icon"
                :src="good.icon"
                v-if="good.icon"
              />
              {{good.name}}
            </span>
          </li>
        </ul>
      </div>
      <!--右侧商品列表--菜单-->
      <div class="foods-wrapper" ref="foodsWrapper">
        <ul ref="foodsUI">
          <li class="food-list-hook" v-for="(good,index) in goods" :key="index">
            <h1 class="title">{{good.name}}</h1>
            <ul>
              <li class="food-item bottom-border-1px" v-for="(food,index) in good.foods" :key="index">
                <div class="icon">
                  <img
                    width="57"
                    height="57"
                    :src="food.icon"
                  />
                </div>
                <div class="content">
                  <h2 class="name">{{food.name}}</h2>
                  <p class="desc">{{food.description}}</p>
                  <div class="extra">
                    <span class="count">月售 {{food.sellCount}} 份</span>
                    <span>好评率 {{food.rating}}%</span>
                  </div>
                  <div class="price">
                    <span class="now">￥{{food.price}}</span>
                  </div>
                  <div class="cartcontrol-wrapper">CartControl</div>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
//1:读取商家商品信息
import {mapState} from "vuex"
//2:引入滚动条组件
import BScroll from "better-scroll"
export default {
  computed: {
    ...mapState(['goods']) //2:读取商家信息
  },
  components: { 
  },
  data() {
    return {};
  },
  mounted() {
    //17:40 检查代码输出结果 ->ajax data dom  20ms
    this.$store.dispatch("getShopGoods").then(()=>{
      this.$nextTick(()=>{
         //console.log(this.$store)
         this._initScroll();    //0.1ms error 10:26 完成..
         //解决方案:等待上面元素DOM更新结束
         this._initTops();
      })
    })
  },
  methods: {
     //当前组件创建成功创建多个对象和方法..初始值单独写一个方法
     _initScroll(){
       //0:文件开始引入第三方组件better-scroll
       //1:创建better-scroll对象 绑定左侧菜单
       new BScroll(".menu-wrapper",{
         click:true          //左侧菜单支持点击事件右侧联动
       })
       //2:创建better-scroll对象 绑定右侧菜单 10:51
       this.foodsScroll = new BScroll(".foods-wrapper",{
         probeType:2,//滑动与滑动结束时触发
         click:true
       })
       //3:为右侧better-scroll对象绑定事件 scroll
       this.foodsScroll.on("scroll",({x,y})=>{console.log(x,y)});
       //4:为右侧better-scroll对象绑定事件 scrollEnd
       this.foodsScroll.on("scrollEnd",({x,y})=>{console.log(x,y)})
     },
     //计算所有商品类别元素高度! 10:17
     _initTops(){
      //1:创建数组 tops
      const tops = [];
      //2:创建变量 top = 0 优惠li顶端位置 x,y=0;
      let top = 0;
      //3:将top添加数组
      tops.push(top);
      //4:查找右侧所有li元素
      const lis = this.$refs.foodsUI.getElementsByClassName("food-list-hook");
      //5:创建循环遍历所有li获取高度累加保存 0 1000 1300 1400
      Array.prototype.slice.call(lis).forEach(li=>{
        top += li.clientHeight;
        tops.push(top);
      })
      //6:将数组tops 保存data
      this.tops = tops;
      //console.log(tops)
     },
  },
};
</script>
<style lang='stylus' rel='stylesheet/stylus' scoped>
@import '../../../common/stylus/minxns.styl';

.goods {
  display: flex;
  position: absolute;
  top: 195px;
  bottom: 46px;
  width: 100%;
  background: #fff;
  overflow: hidden;

  .menu-wrapper {
    flex: 0 0 80px;
    width: 80px;
    background: #f3f5f7;

    .menu-item {
      display: table;
      height: 54px;
      width: 56px;
      padding: 0 12px;
      line-height: 14px;

      &.current {
        position: relative;
        z-index: 10;
        margin-top: -1px;
        background: #fff;
        color: $green;
        font-weight: 700;

        .text {
          border-none();
        }
      }

      .icon {
        display: inline-block;
        vertical-align: top;
        width: 12px;
        height: 12px;
        margin-right: 2px;
        background-size: 12px 12px;
        background-repeat: no-repeat;
      }

      .text {
        display: table-cell;
        width: 56px;
        vertical-align: middle;
        bottom-border-1px(rgba(7, 17, 27, 0.1));
        font-size: 12px;
      }
    }
  }

  .foods-wrapper {
    flex: 1;

    .title {
      padding-left: 14px;
      height: 26px;
      line-height: 26px;
      border-left: 2px solid #d9dde1;
      font-size: 12px;
      color: rgb(147, 153, 159);
      background: #f3f5f7;
    }

    .food-item {
      display: flex;
      margin: 18px;
      padding-bottom: 18px;
      bottom-border-1px(rgba(7, 17, 27, 0.1));

      &:last-child {
        border-none();
        margin-bottom: 0;
      }

      .icon {
        flex: 0 0 57px;
        margin-right: 10px;
      }

      .content {
        flex: 1;

        .name {
          margin: 2px 0 8px 0;
          height: 14px;
          line-height: 14px;
          font-size: 14px;
          color: rgb(7, 17, 27);
        }

        .desc, .extra {
          line-height: 10px;
          font-size: 10px;
          color: rgb(147, 153, 159);
        }

        .desc {
          line-height: 12px;
          margin-bottom: 8px;
        }

        .extra {
          .count {
            margin-right: 12px;
          }
        }

        .price {
          font-weight: 700;
          line-height: 24px;

          .now {
            margin-right: 8px;
            font-size: 14px;
            color: rgb(240, 20, 20);
          }

          .old {
            text-decoration: line-through;
            font-size: 10px;
            color: rgb(147, 153, 159);
          }
        }

        .cartcontrol-wrapper {
          position: absolute;
          right: 0;
          bottom: 12px;
        }
      }
    }
  }
}
</style>